# Feature status and scope

This status document describes only what is present in this ZIP. The 210-item original brief is preserved in `SPECIFICATION-210-FEATURES.md`.

## Working in this browser build

- Dashboard counters, recent projects/activity and navigation
- Create, edit, delete and browse projects
- Local workspace save plus JSON backup/import
- Scene create/edit/copy/delete and scene prompt/detail fields
- Script draft form and locally generated structured draft text
- Character and location reference records with editable continuity notes
- Image/video prompt preparation and local prompt/brief records
- Local image reference upload/removal (browser storage limits apply)
- Storyboard cards created from scenes, reordering, scene editing and browser print-to-PDF
- Basic media import, clip arrangement, trimming/splitting/moving/deleting and individual preview playback
- Clip-level volume/speed controls and separate timeline track categories
- Thumbnail canvas designer and PNG download
- Publishing metadata draft helper, per-project checklist and JSON project handoff

## Partial workflows / limited implementation

- Script and publishing helpers are templates/rule-based, not connected to a language model
- Image/video studios prepare prompts and request briefs; they do not generate media
- Character/location continuity is stored as reference notes; no AI consistency analysis runs
- Timeline supports basic clip arrangement and preview, not full multi-clip rendered playback or professional editing
- Audio is handled as imported media/clip metadata; no automatic speech, transcription, noise reduction or mastering
- Storyboard PDF uses the browser print dialog rather than a server-side PDF renderer
- Storage is local to one browser profile; it is not a cloud backup or multi-device sync

## Not implemented / requires future backend or development

- User authentication, roles, secure multi-user ownership and collaboration
- PostgreSQL or another server database, secure object storage and hosted backups
- AI provider integrations for text, image, video, voice and audio
- Server-side API key vault, model/provider selection, usage billing and generation queue workers
- Full professional NLE: robust multi-track compositing, keyframes, transitions, waveform editing, frame-accurate render pipeline and undo/redo history
- FFmpeg rendering and actual MP4 export
- Advanced animation/effects, chroma key and background removal integrations
- Direct YouTube/social publishing
- Full 210-feature acceptance testing and production deployment
- Public ChatGPT plugin publication

## Important

A navigation item or roadmap mention is not evidence that a feature is implemented. Features not listed under “Working” above should be treated as partial or not implemented. Do not use this prototype for sensitive data or rely on it as the only copy of important project files.
