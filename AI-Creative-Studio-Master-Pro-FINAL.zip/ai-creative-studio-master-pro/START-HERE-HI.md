# शुरू कैसे करें

1. ZIP फाइल डाउनलोड करके Extract करें।
2. `ai-creative-studio-master-pro` फोल्डर खोलें।
3. `index.html` को Chrome या किसी आधुनिक browser में खोलें।
4. **My Projects** में नया project बनाएँ।
5. काम के दौरान **Export workspace** से backup निकालते रहें।

## इस ZIP में क्या है?

Dashboard, Projects, Script Draft Studio, Scene Editor, Character/Location references, Image/Video prompt tools, Storyboard, basic Video Timeline, Audio clip workflow, Thumbnail PNG maker, Publishing checklist और JSON backup/export के browser-based modules शामिल हैं।

## जरूरी सीमा

यह अभी browser में चलने वाला prototype/foundation है। सभी 210 सुविधाएँ पूरी नहीं हुई हैं। असली AI image/video/voice generation, secure login, cloud sync, FFmpeg MP4 rendering, advanced editor, direct YouTube publishing और public ChatGPT plugin के लिए अलग backend, provider APIs और hosting की जरूरत है। कोई नकली AI generation या MP4 export उपलब्ध होने का दावा नहीं है।
